"""MediMinder - Medicine Schedule Reminder.  Run:  python main.py"""
import sys


def main():
    try:
        from app.gui import run
    except ImportError as exc:
        if "tkinter" in str(exc).lower():
            print("Tkinter is not available in this Python installation.\n"
                  "  Windows/macOS: reinstall Python from python.org (tick 'tcl/tk').\n"
                  "  Ubuntu/Debian: sudo apt install python3-tk\n"
                  "  Fedora: sudo dnf install python3-tkinter")
            sys.exit(1)
        raise
    run()


if __name__ == "__main__":
    main()
