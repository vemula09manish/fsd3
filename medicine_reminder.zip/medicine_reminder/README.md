# 💊 MediMinder – Medicine Schedule Reminder
Python for Good · Project #36 · Health & Wellbeing

A desktop app (Tkinter GUI) to store medicines and dose schedules, show in-app reminders,
track adherence, and export reports. Data is saved locally in `data/medicines.json`.

## Run in VS Code
1. Unzip and open the folder: **File → Open Folder → `medicine_reminder`**
2. Open a terminal (**Ctrl + `**) and create a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
3. Install the only dependency: `pip install -r requirements.txt`
4. Run: `python main.py`  (or press **F5** and choose *Run MediMinder*)

> Linux only: if Tkinter is missing, run `sudo apt install python3-tk`.
> Requires Python 3.10+.

## Features
| Requirement | Where |
|---|---|
| Menu-driven interface | Tabs: Dashboard · Medicines · Analytics · Reports & Import |
| Defensive validation | `app/validation.py` (names, HH:MM times, dates, stock range, duplicates) |
| Core logic | `app/logic.py` (today's schedule, Taken/Skip, stock deduction, adherence) |
| Persistence (JSON) | `app/storage.py` – atomic saves, auto-recovers from corrupt/missing files |
| Search & filter | Medicines tab: keyword + category + status (incl. *Low stock*) |
| Executive summary | Analytics tab |
| Matplotlib charts | Category mix · 7-day adherence · stock levels · dose times |
| Export (stretch) | Markdown, text audit log, CSV, chart PNGs |
| Threshold warnings (stretch) | Out of stock, low stock, expired, ending soon, due/missed doses |
| Bulk CSV import (stretch) | Row-by-row error log saved to `exports/` |
| In-app reminders | Pop-up when a dose is due: **Taken / Snooze 10 min / Skip** |

## Demo script (hackathon)
1. Launch – demo data (41 medicines + 7 days of history) loads on first run.
2. **Dashboard → 🔔 Test reminder** to show the pop-up.
3. **Medicines → Add medicine**: type `25:00` as time and a negative stock to show validation catching errors, then fix and save.
4. **Analytics**: summary + charts.
5. **Reports & Import → Import CSV** → pick `data/sample_import_with_errors.csv` (2 good rows, 8 rejected with reasons).
6. Close and relaunch – everything is still there. Export a Markdown report.

To reset to demo data, delete `data/medicines.json`.

## Project layout
```
main.py                  entry point
app/gui.py               Tkinter interface + reminder loop
app/logic.py             business logic
app/validation.py        input checks
app/storage.py           JSON persistence
app/reports.py           exports, CSV import, Matplotlib charts
data/                    sample_medicines.csv / .json, sample_import_with_errors.csv
tests/test_core.py       python -m unittest discover -s tests
```
