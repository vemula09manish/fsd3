import csv, json, sys, tempfile, unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import logic, reports
from app.models import Medicine
from app.storage import Store
from app.validation import parse_times, validate_medicine_form

NOW = datetime(2026, 11, 23, 9, 10)
DATA = Path(__file__).resolve().parent.parent / "data"


def med(**kw):
    base = dict(name="Test", dosage="5 mg", category="Other", times=["09:00"],
                start_date="2026-11-01", end_date="", stock=10, notes="", active=True)
    base.update(kw)
    return Medicine(**base)


class ValidationTests(unittest.TestCase):
    def test_times(self):
        self.assertEqual(parse_times("8:00, 20:30")[0], ["08:00", "20:30"])
        self.assertTrue(parse_times("25:00")[1])
        self.assertTrue(parse_times("")[1])

    def test_valid_and_invalid_form(self):
        ok, errs = validate_medicine_form(dict(name="Aspirin", dosage="75 mg", category="heart & bp",
                                               times="09:00", start_date="2026-11-01", end_date="", stock="5"))
        self.assertFalse(errs)
        self.assertEqual(ok["category"], "Heart & BP")
        bad, errs = validate_medicine_form(dict(name="", dosage="", category="x", times="99",
                                                start_date="bad", end_date="", stock="-3"))
        self.assertIsNone(bad)
        self.assertGreaterEqual(len(errs), 6)

    def test_end_before_start_and_duplicates(self):
        _, errs = validate_medicine_form(dict(name="A1", dosage="1", category="Other", times="09:00",
                                              start_date="2026-11-10", end_date="2026-11-01", stock="1"))
        self.assertTrue(any("End date" in e for e in errs))
        _, errs = validate_medicine_form(dict(name="test", dosage="5 MG", category="Other", times="09:00",
                                              start_date="2026-11-01", end_date="", stock="1"), [med()])
        self.assertTrue(any("already exists" in e for e in errs))


class LogicTests(unittest.TestCase):
    def test_schedule_status_and_stock(self):
        m = med(times=["08:00", "09:00", "18:00"], stock=2)
        logs = []
        st = {r["time"]: r["status"] for r in logic.today_schedule([m], logs, NOW)}
        self.assertEqual(st, {"08:00": "Missed", "09:00": "Due", "18:00": "Upcoming"})
        self.assertTrue(logic.mark_dose([m], logs, m.id, "2026-11-23", "09:00", "Taken", NOW))
        self.assertFalse(logic.mark_dose([m], logs, m.id, "2026-11-23", "09:00", "Taken", NOW))
        self.assertEqual(m.stock, 1)

    def test_warnings(self):
        meds = [med(name="Zero", stock=0), med(name="Low", stock=2, times=["23:00"]),
                med(name="Old", end_date="2026-11-01", times=["23:00"])]
        levels = [w[0] for w in logic.get_warnings(meds, [], NOW)]
        self.assertIn("critical", levels)
        self.assertIn("warning", levels)

    def test_search_and_summary(self):
        meds = [med(name="Aspirin", category="Heart & BP", stock=1), med(name="Vit C", category="Vitamins & Supplements")]
        self.assertEqual(len(logic.search(meds, "asp", today=NOW.date())), 1)
        self.assertEqual(len(logic.search(meds, status="Low stock", today=NOW.date())), 1)
        s = logic.summary(meds, [], NOW)
        self.assertEqual(s["total"], 2)
        self.assertEqual(s["doses_per_day"], 2)


class StorageAndReportTests(unittest.TestCase):
    def test_round_trip_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "db.json"
            s = Store(p, seed_demo=False); s.load()
            s.medicines.append(med()); s.save()
            s2 = Store(p, seed_demo=False); s2.load()
            self.assertEqual(len(s2.medicines), 1)
            p.write_text("{not json")
            s3 = Store(p, seed_demo=False); s3.load()
            self.assertEqual(s3.medicines, [])
            self.assertTrue(s3.notice)
            self.assertTrue(p.with_suffix(".corrupt.bak").exists())

    def test_sample_data_and_import_errors(self):
        data = json.loads((DATA / "sample_medicines.json").read_text())
        self.assertTrue(30 <= len(data["medicines"]) <= 50)
        existing = [Medicine.from_dict(d) for d in data["medicines"]]
        added, errors = reports.import_csv(DATA / "sample_import_with_errors.csv", existing)
        self.assertEqual(len(added), 2)
        self.assertEqual(len(errors), 8)

    def test_exports(self):
        meds = [med()]
        with tempfile.TemporaryDirectory() as d:
            reports.export_markdown(Path(d) / "r.md", meds, [], NOW)
            reports.export_text(Path(d) / "r.txt", meds, [], NOW)
            reports.export_csv(Path(d) / "r.csv", meds)
            self.assertIn("# Medicine Schedule Report", (Path(d) / "r.md").read_text())
            self.assertEqual(len(list(csv.DictReader(open(Path(d) / "r.csv")))), 1)
            try:
                paths = reports.save_charts(d, meds, [], NOW)
                self.assertEqual(len(paths), 4)
            except ImportError:
                pass


if __name__ == "__main__":
    unittest.main()
