"""Report export (Markdown / text / CSV), CSV import with error log, and Matplotlib charts."""
from __future__ import annotations

import csv
from collections import Counter
from datetime import datetime
from pathlib import Path

from . import logic
from .models import Medicine
from .validation import validate_medicine_form

CSV_FIELDS = ["name", "dosage", "category", "times", "start_date", "end_date", "stock", "notes", "active"]


# ---------------------------------------------------------------- summary text
def summary_text(meds, logs, now: datetime) -> str:
    s = logic.summary(meds, logs, now)
    adh = f"{s['adherence_7d']}%" if s["adherence_7d"] is not None else "n/a"
    lines = [
        f"MEDICINE SCHEDULE SUMMARY  -  {now:%Y-%m-%d %H:%M}",
        "=" * 52,
        f"Total medicines        : {s['total']}",
        f"  Active / Scheduled   : {s['active']} / {s['scheduled']}",
        f"  Inactive / Expired   : {s['inactive']} / {s['expired']}",
        f"Scheduled doses per day: {s['doses_per_day']}",
        f"Avg doses per medicine : {s['avg_doses_per_med']}",
        f"Average stock (active) : {s['avg_stock']} units",
        f"7-day adherence        : {adh}",
        f"Today                  : {s['today_taken']} taken, {s['today_pending']} pending, {s['today_missed']} missed",
        "", "By category:",
    ]
    for cat, n in s["by_category"].most_common():
        lines.append(f"  - {cat:<24} {n}")
    lines += ["", "Warnings:"]
    warns = logic.get_warnings(meds, logs, now)
    lines += [f"  [{lvl.upper():8}] {msg}" for lvl, msg in warns] or ["  None - all good!"]
    return "\n".join(lines)


# ---------------------------------------------------------------- exports
def export_text(path, meds, logs, now: datetime):
    body = [summary_text(meds, logs, now), "", "MEDICINE LIST", "-" * 52]
    for m in sorted(meds, key=lambda x: x.name.lower()):
        body.append(f"{m.name} ({m.dosage}) | {m.category} | {', '.join(m.times)} | stock {m.stock} | "
                    f"{logic.med_status(m, now.date())}")
    body += ["", "AUDIT LOG (last 50 dose entries)", "-" * 52]
    names = {m.id: m.name for m in meds}
    for l in logs[-50:]:
        body.append(f"{l.get('logged_at', l['date'])}  {names.get(l['med_id'], '?'):<28} {l['time']}  {l['status']}")
    Path(path).write_text("\n".join(body) + "\n", encoding="utf-8")


def export_markdown(path, meds, logs, now: datetime):
    s = logic.summary(meds, logs, now)
    adh = f"{s['adherence_7d']}%" if s["adherence_7d"] is not None else "n/a"
    md = [f"# Medicine Schedule Report", f"_Generated {now:%Y-%m-%d %H:%M}_", "",
          "## Key Metrics", "",
          "| Metric | Value |", "|---|---|",
          f"| Total medicines | {s['total']} |", f"| Active | {s['active']} |",
          f"| Expired | {s['expired']} |", f"| Doses per day | {s['doses_per_day']} |",
          f"| Average stock | {s['avg_stock']} |", f"| 7-day adherence | {adh} |", "",
          "## Warnings", ""]
    warns = logic.get_warnings(meds, logs, now)
    md += [f"- **{lvl.upper()}** - {msg}" for lvl, msg in warns] or ["- None"]
    md += ["", "## Medicines", "", "| Name | Dosage | Category | Times | Stock | Status |", "|---|---|---|---|---|---|"]
    for m in sorted(meds, key=lambda x: x.name.lower()):
        md.append(f"| {m.name} | {m.dosage} | {m.category} | {', '.join(m.times)} | {m.stock} | "
                  f"{logic.med_status(m, now.date())} |")
    Path(path).write_text("\n".join(md) + "\n", encoding="utf-8")


def export_csv(path, meds):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        w.writeheader()
        for m in sorted(meds, key=lambda x: x.name.lower()):
            d = m.to_dict()
            d["times"] = ";".join(m.times)
            w.writerow({k: d[k] for k in CSV_FIELDS})


# ---------------------------------------------------------------- bulk import
def import_csv(path, existing: list[Medicine]):
    """Import a legacy CSV. Returns (added_medicines, errors[(line, message)])."""
    added, errors = [], []
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        headers = {(h or "").strip().lower() for h in (reader.fieldnames or [])}
        missing = {"name", "dosage", "category", "times", "start_date", "stock"} - headers
        if missing:
            raise ValueError("CSV is missing required column(s): " + ", ".join(sorted(missing)))
        for line_no, row in enumerate(reader, start=2):
            row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
            clean, errs = validate_medicine_form(row, existing + added)
            if errs:
                errors.append((line_no, "; ".join(errs)))
            else:
                added.append(Medicine(**clean))
    return added, errors


def write_import_log(path, source, added_count, errors):
    lines = [f"Import log - {source}", f"Imported rows : {added_count}", f"Rejected rows : {len(errors)}", ""]
    lines += [f"Row {n}: {msg}" for n, msg in errors]
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- charts
def build_figures(meds, logs, now: datetime) -> dict:
    """Return {title: matplotlib Figure}. Raises ImportError if matplotlib is missing."""
    from matplotlib.figure import Figure

    blue, green, red, amber = "#2563eb", "#16a34a", "#dc2626", "#f59e0b"
    figs = {}
    s = logic.summary(meds, logs, now)

    # 1. category distribution
    fig = Figure(figsize=(6.4, 3.6), dpi=100)
    ax = fig.add_subplot(111)
    cats = Counter(m.category for m in meds).most_common()
    if cats:
        ax.barh([c for c, _ in cats][::-1], [n for _, n in cats][::-1], color=blue)
        for i, (_, n) in enumerate(cats[::-1]):
            ax.text(n + 0.1, i, str(n), va="center", fontsize=9)
    ax.set_title("Medicines by category"); ax.set_xlabel("Count")
    fig.tight_layout(); figs["Categories"] = fig

    # 2. adherence trend
    fig = Figure(figsize=(6.4, 3.6), dpi=100)
    ax = fig.add_subplot(111)
    days = [d.strftime("%a %d") for d, _ in s["trend"]]
    vals = [v if v is not None else 0 for _, v in s["trend"]]
    ax.plot(days, vals, marker="o", color=green, linewidth=2)
    ax.fill_between(range(len(days)), vals, alpha=0.12, color=green)
    ax.axhline(80, color=amber, linestyle="--", linewidth=1, label="80% target")
    ax.set_ylim(0, 105); ax.set_ylabel("Doses taken (%)"); ax.set_title("7-day adherence trend")
    ax.legend(loc="lower left"); fig.tight_layout(); figs["Adherence"] = fig

    # 3. stock levels
    fig = Figure(figsize=(6.4, 3.6), dpi=100)
    ax = fig.add_subplot(111)
    live = sorted([m for m in meds if logic.med_status(m, now.date()) in ("Active", "Scheduled")],
                  key=lambda m: m.stock)[:10]
    if live:
        colors = [red if m.stock <= logic.LOW_STOCK_THRESHOLD else blue for m in live]
        ax.barh([m.name[:22] for m in live][::-1], [m.stock for m in live][::-1], color=colors[::-1])
        ax.axvline(logic.LOW_STOCK_THRESHOLD, color=red, linestyle="--", linewidth=1, label="Low-stock limit")
        ax.legend(loc="lower right")
    ax.set_title("Lowest stock levels (10 medicines)"); ax.set_xlabel("Units left")
    fig.tight_layout(); figs["Stock"] = fig

    # 4. dose time distribution
    fig = Figure(figsize=(6.4, 3.6), dpi=100)
    ax = fig.add_subplot(111)
    hours = Counter(int(t.split(":")[0]) for m in meds if m.active for t in m.times)
    ax.bar(range(24), [hours.get(h, 0) for h in range(24)], color=amber)
    ax.set_xticks(range(0, 24, 2)); ax.set_xlabel("Hour of day"); ax.set_ylabel("Scheduled doses")
    ax.set_title("When are doses scheduled?"); fig.tight_layout(); figs["Dose times"] = fig
    return figs


def save_charts(folder, meds, logs, now: datetime) -> list[Path]:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for title, fig in build_figures(meds, logs, now).items():
        p = folder / f"chart_{title.lower().replace(' ', '_')}.png"
        fig.savefig(p)
        paths.append(p)
    return paths
