"""Data structures for medicines and dose logs."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict

CATEGORIES = [
    "Pain Relief", "Antibiotic", "Heart & BP", "Diabetes",
    "Vitamins & Supplements", "Allergy", "Digestive",
    "Respiratory", "Mental Health", "Other",
]


@dataclass
class Medicine:
    name: str
    dosage: str
    category: str
    times: list = field(default_factory=list)   # ["08:00", "20:00"]
    start_date: str = ""                         # YYYY-MM-DD
    end_date: str = ""                           # "" = ongoing
    stock: int = 0                               # units left
    notes: str = ""
    active: bool = True
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Medicine":
        return cls(
            name=str(d.get("name", "")),
            dosage=str(d.get("dosage", "")),
            category=str(d.get("category", "Other")),
            times=list(d.get("times", [])),
            start_date=str(d.get("start_date", "")),
            end_date=str(d.get("end_date", "") or ""),
            stock=int(d.get("stock", 0)),
            notes=str(d.get("notes", "")),
            active=bool(d.get("active", True)),
            id=str(d.get("id") or uuid.uuid4().hex[:8]),
        )
