"""MediMinder GUI (Tkinter + ttk, optional embedded Matplotlib charts)."""
from __future__ import annotations

import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, simpledialog, ttk

from . import logic, reports
from .models import CATEGORIES, Medicine
from .storage import EXPORT_DIR, Store
from .validation import MAX_STOCK, validate_medicine_form

# ------------------------------------------------------------------ theme
PRIMARY, PRIMARY_DARK = "#2563eb", "#1e40af"
BG, CARD, TEXT, MUTED = "#f1f5f9", "#ffffff", "#0f172a", "#64748b"
GREEN, RED, AMBER, BLUE = "#16a34a", "#dc2626", "#d97706", "#2563eb"
FONT = ("Segoe UI", 10)
FONT_B = ("Segoe UI", 10, "bold")
STATUS_COLORS = {"Taken": GREEN, "Skipped": MUTED, "Missed": RED, "Due": AMBER, "Upcoming": BLUE}
LEVEL_COLORS = {"critical": RED, "warning": AMBER, "info": BLUE}
LEVEL_ICONS = {"critical": "\u26d4", "warning": "\u26a0\ufe0f", "info": "\u2139\ufe0f"}


class MedicineDialog(tk.Toplevel):
    """Add / edit form with defensive validation."""

    def __init__(self, app, medicine: Medicine | None = None):
        super().__init__(app.root)
        self.app, self.medicine = app, medicine
        self.title("Edit medicine" if medicine else "Add medicine")
        self.configure(bg=CARD, padx=24, pady=20)
        self.resizable(False, False)
        self.transient(app.root)

        m = medicine
        self.vars = {
            "name": tk.StringVar(value=m.name if m else ""),
            "dosage": tk.StringVar(value=m.dosage if m else ""),
            "category": tk.StringVar(value=m.category if m else CATEGORIES[0]),
            "times": tk.StringVar(value=", ".join(m.times) if m else "08:00"),
            "start_date": tk.StringVar(value=m.start_date if m else datetime.now().strftime("%Y-%m-%d")),
            "end_date": tk.StringVar(value=m.end_date if m else ""),
            "stock": tk.StringVar(value=str(m.stock) if m else "30"),
            "notes": tk.StringVar(value=m.notes if m else ""),
            "active": tk.BooleanVar(value=m.active if m else True),
        }
        fields = [
            ("Medicine name *", "name", None), ("Dosage * (e.g. 500 mg)", "dosage", None),
            ("Category *", "category", "combo"),
            ("Dose times * (HH:MM, comma separated)", "times", None),
            ("Start date * (YYYY-MM-DD)", "start_date", None),
            ("End date (optional)", "end_date", None),
            ("Units in stock *", "stock", None), ("Notes", "notes", None),
        ]
        for r, (label, key, kind) in enumerate(fields):
            ttk.Label(self, text=label, style="Card.TLabel").grid(row=r, column=0, sticky="w", pady=6, padx=(0, 16))
            if kind == "combo":
                w = ttk.Combobox(self, textvariable=self.vars[key], values=CATEGORIES, state="readonly", width=34)
            else:
                w = ttk.Entry(self, textvariable=self.vars[key], width=36)
            w.grid(row=r, column=1, sticky="ew", pady=6)
            if r == 0:
                w.focus_set()
        ttk.Checkbutton(self, text="Reminders active", variable=self.vars["active"],
                        style="Card.TCheckbutton").grid(row=len(fields), column=1, sticky="w", pady=6)

        btns = tk.Frame(self, bg=CARD)
        btns.grid(row=len(fields) + 1, column=0, columnspan=2, sticky="e", pady=(14, 0))
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(btns, text="Save", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Return>", lambda e: self.save())
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()

    def save(self):
        raw = {k: v.get() for k, v in self.vars.items()}
        clean, errors = validate_medicine_form(
            raw, self.app.store.medicines, ignore_id=self.medicine.id if self.medicine else None)
        if errors:
            messagebox.showerror("Please fix the following",
                                 "\n".join(f"\u2022 {e}" for e in errors), parent=self)
            return
        if self.medicine:
            for k, v in clean.items():
                setattr(self.medicine, k, v)
        else:
            self.app.store.medicines.append(Medicine(**clean))
        self.app.store.save()
        self.app.refresh_all()
        self.app.set_status(f"Saved {clean['name']}.")
        self.destroy()


class MedicineApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("MediMinder \u2013 Medicine Schedule Reminder")
        root.geometry("1220x780")
        root.minsize(1040, 660)
        root.configure(bg=BG)

        self.store = Store()
        self.store.load()
        self.notified: set = set()

        self._setup_style()
        self._build_header()
        self._build_tabs()
        self._build_statusbar()

        self.refresh_all()
        self._tick()
        self.root.after(1500, self.check_reminders)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        if self.store.notice:
            self.root.after(400, lambda: messagebox.showinfo("MediMinder", self.store.notice))

    # ------------------------------------------------------------ style
    def _setup_style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", font=FONT, background=BG, foreground=TEXT)
        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=CARD)
        s.configure("Card.TLabel", background=CARD, foreground=TEXT)
        s.configure("Card.TCheckbutton", background=CARD)
        s.configure("TLabel", background=BG)
        s.configure("Title.TLabel", background=BG, font=("Segoe UI", 13, "bold"))
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", padding=(22, 10), font=FONT_B, background="#e2e8f0", foreground=MUTED)
        s.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", PRIMARY)])
        s.configure("Treeview", rowheight=30, font=FONT, background=CARD, fieldbackground=CARD, borderwidth=0)
        s.configure("Treeview.Heading", font=FONT_B, background="#e2e8f0", foreground=TEXT, padding=6)
        s.map("Treeview", background=[("selected", "#dbeafe")], foreground=[("selected", TEXT)])
        s.configure("TButton", padding=(14, 7), font=FONT_B)
        s.configure("Accent.TButton", background=PRIMARY, foreground="white")
        s.map("Accent.TButton", background=[("active", PRIMARY_DARK)])
        s.configure("Danger.TButton", background=RED, foreground="white")
        s.map("Danger.TButton", background=[("active", "#991b1b")])
        s.configure("Good.TButton", background=GREEN, foreground="white")
        s.map("Good.TButton", background=[("active", "#166534")])

    def _build_header(self):
        bar = tk.Frame(self.root, bg=PRIMARY)
        bar.pack(fill="x")
        tk.Label(bar, text="\U0001f48a  MediMinder", bg=PRIMARY, fg="white",
                 font=("Segoe UI", 20, "bold")).pack(side="left", padx=22, pady=14)
        tk.Label(bar, text="Medicine Schedule Reminder", bg=PRIMARY, fg="#bfdbfe",
                 font=("Segoe UI", 11)).pack(side="left", pady=(10, 0))
        self.clock = tk.Label(bar, bg=PRIMARY, fg="white", font=("Segoe UI", 12, "bold"))
        self.clock.pack(side="right", padx=22)

    def _build_statusbar(self):
        self.status = tk.StringVar(value="Ready")
        tk.Label(self.root, textvariable=self.status, anchor="w", bg="#e2e8f0", fg=MUTED,
                 padx=14, pady=5, font=("Segoe UI", 9)).pack(side="bottom", fill="x")

    def set_status(self, msg: str):
        self.status.set(msg)

    def _build_tabs(self):
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=14, pady=(12, 6))
        self.tab_dash = ttk.Frame(self.nb, padding=14)
        self.tab_meds = ttk.Frame(self.nb, padding=14)
        self.tab_stats = ttk.Frame(self.nb, padding=14)
        self.tab_reports = ttk.Frame(self.nb, padding=14)
        self.nb.add(self.tab_dash, text="  \U0001f3e0 Dashboard  ")
        self.nb.add(self.tab_meds, text="  \U0001f48a Medicines  ")
        self.nb.add(self.tab_stats, text="  \U0001f4ca Analytics  ")
        self.nb.add(self.tab_reports, text="  \U0001f4c4 Reports & Import  ")
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.refresh_analytics())
        self._build_dashboard()
        self._build_meds_tab()
        self._build_stats_tab()
        self._build_reports_tab()

    # ------------------------------------------------------------ dashboard
    def _card(self, parent, title, color):
        f = tk.Frame(parent, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        tk.Frame(f, bg=color, height=4).pack(fill="x")
        v = tk.Label(f, text="-", bg=CARD, fg=color, font=("Segoe UI", 26, "bold"))
        v.pack(pady=(10, 0))
        tk.Label(f, text=title, bg=CARD, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(pady=(0, 12))
        return f, v

    def _build_dashboard(self):
        top = ttk.Frame(self.tab_dash)
        top.pack(fill="x")
        self.cards = {}
        for i, (key, title, color) in enumerate([
            ("active", "ACTIVE MEDICINES", PRIMARY), ("today", "TODAY'S DOSES", BLUE),
            ("taken", "TAKEN TODAY", GREEN), ("adherence", "7-DAY ADHERENCE", AMBER),
            ("warn", "WARNINGS", RED)]):
            f, v = self._card(top, title, color)
            f.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0))
            top.columnconfigure(i, weight=1)
            self.cards[key] = v

        body = ttk.Frame(self.tab_dash)
        body.pack(fill="both", expand=True, pady=(14, 0))
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        tk.Label(left, text="Today's schedule", bg=CARD, font=("Segoe UI", 13, "bold"),
                 anchor="w").pack(fill="x", padx=14, pady=(12, 6))
        cols = ("time", "medicine", "dosage", "status")
        self.sched_tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        for c, w, t in (("time", 80, "Time"), ("medicine", 230, "Medicine"),
                        ("dosage", 110, "Dosage"), ("status", 100, "Status")):
            self.sched_tree.heading(c, text=t)
            self.sched_tree.column(c, width=w, anchor="w")
        for st, col in STATUS_COLORS.items():
            self.sched_tree.tag_configure(st, foreground=col)
        sb = ttk.Scrollbar(left, orient="vertical", command=self.sched_tree.yview)
        self.sched_tree.configure(yscrollcommand=sb.set)
        btns = tk.Frame(left, bg=CARD)
        btns.pack(side="bottom", fill="x", padx=14, pady=10)
        ttk.Button(btns, text="\u2714 Mark taken", style="Good.TButton",
                   command=lambda: self.log_selected("Taken")).pack(side="left")
        ttk.Button(btns, text="Skip", command=lambda: self.log_selected("Skipped")).pack(side="left", padx=8)
        ttk.Button(btns, text="\U0001f514 Test reminder", command=self.test_reminder).pack(side="right")
        self.sched_tree.pack(side="left", fill="both", expand=True, padx=(14, 0), pady=(0, 0))
        sb.pack(side="left", fill="y", padx=(0, 6))

        right = tk.Frame(body, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew")
        tk.Label(right, text="Alerts & warnings", bg=CARD, font=("Segoe UI", 13, "bold"),
                 anchor="w").pack(fill="x", padx=14, pady=(12, 6))
        self.warn_text = tk.Text(right, wrap="word", bg=CARD, relief="flat", font=FONT,
                                 padx=14, pady=4, state="disabled", cursor="arrow")
        for lvl, col in LEVEL_COLORS.items():
            self.warn_text.tag_configure(lvl, foreground=col, spacing3=8)
        self.warn_text.tag_configure("ok", foreground=GREEN)
        self.warn_text.pack(fill="both", expand=True)

    def refresh_dashboard(self):
        now = datetime.now()
        s = logic.summary(self.store.medicines, self.store.logs, now)
        warns = logic.get_warnings(self.store.medicines, self.store.logs, now)
        self.cards["active"].config(text=str(s["active"]))
        self.cards["today"].config(text=str(s["today_total"]))
        self.cards["taken"].config(text=str(s["today_taken"]))
        self.cards["adherence"].config(text="n/a" if s["adherence_7d"] is None else f"{s['adherence_7d']:.0f}%")
        self.cards["warn"].config(text=str(len(warns)))

        sel = self.sched_tree.selection()
        keep = sel[0] if sel else None
        self.sched_tree.delete(*self.sched_tree.get_children())
        for r in logic.today_schedule(self.store.medicines, self.store.logs, now):
            iid = f"{r['med'].id}|{r['time']}"
            icon = {"Taken": "\u2714 ", "Skipped": "\u2013 ", "Missed": "\u2716 ", "Due": "\u23f0 "}.get(r["status"], "")
            self.sched_tree.insert("", "end", iid=iid, tags=(r["status"],),
                                   values=(r["time"], r["med"].name, r["med"].dosage, icon + r["status"]))
        if keep and self.sched_tree.exists(keep):
            self.sched_tree.selection_set(keep)

        self.warn_text.config(state="normal")
        self.warn_text.delete("1.0", "end")
        if not warns:
            self.warn_text.insert("end", "\u2705 Everything looks good!\n", "ok")
        for lvl, msg in warns:
            self.warn_text.insert("end", f"{LEVEL_ICONS[lvl]}  {msg}\n", lvl)
        self.warn_text.config(state="disabled")

    def log_selected(self, status: str):
        sel = self.sched_tree.selection()
        if not sel:
            messagebox.showinfo("Select a dose", "Please select a dose from today's schedule first.")
            return
        med_id, t = sel[0].split("|")
        self.record_dose(med_id, t, status)

    def record_dose(self, med_id: str, t: str, status: str):
        now = datetime.now()
        if logic.mark_dose(self.store.medicines, self.store.logs, med_id, now.strftime("%Y-%m-%d"), t, status, now):
            self.store.save()
            m = self.store.get(med_id)
            self.set_status(f"{m.name} at {t} marked as {status.lower()}.")
            self.refresh_all()
        else:
            self.set_status("That dose was already recorded.")

    # ------------------------------------------------------------ reminders
    def check_reminders(self):
        now = datetime.now()
        for r in logic.today_schedule(self.store.medicines, self.store.logs, now):
            key = (r["med"].id, now.strftime("%Y-%m-%d"), r["time"])
            if r["status"] == "Due" and key not in self.notified:
                self.notified.add(key)
                self.show_reminder(r["med"], r["time"], key)
        self.refresh_dashboard()
        self.root.after(20000, self.check_reminders)

    def show_reminder(self, med: Medicine, t: str, key=None, test: bool = False):
        win = tk.Toplevel(self.root)
        win.title("Medicine reminder")
        win.configure(bg=CARD, padx=28, pady=22)
        win.attributes("-topmost", True)
        win.resizable(False, False)
        tk.Label(win, text="\U0001f514  Time for your medicine", bg=CARD, fg=PRIMARY,
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")
        tk.Label(win, text=f"{med.name}  \u2022  {med.dosage}", bg=CARD, fg=TEXT,
                 font=("Segoe UI", 13)).pack(anchor="w", pady=(12, 2))
        tk.Label(win, text=f"Scheduled at {t}" + (f"   \u2022   {med.notes}" if med.notes else ""),
                 bg=CARD, fg=MUTED).pack(anchor="w")
        if test:
            tk.Label(win, text="(This is a test - nothing will be recorded)", bg=CARD, fg=AMBER).pack(anchor="w", pady=(6, 0))
        row = tk.Frame(win, bg=CARD)
        row.pack(fill="x", pady=(18, 0))

        def act(status):
            win.destroy()
            if not test:
                self.record_dose(med.id, t, status)

        def snooze():
            win.destroy()
            if key:
                self.root.after(10 * 60 * 1000, lambda: self.notified.discard(key))
                self.set_status(f"Snoozed {med.name} for 10 minutes.")

        ttk.Button(row, text="\u2714 Taken", style="Good.TButton", command=lambda: act("Taken")).pack(side="left")
        ttk.Button(row, text="\u23f0 Snooze 10 min", command=snooze).pack(side="left", padx=8)
        ttk.Button(row, text="Skip", command=lambda: act("Skipped")).pack(side="left")
        self.root.bell()

    def test_reminder(self):
        meds = [m for m in self.store.medicines if m.active and m.times]
        if not meds:
            messagebox.showinfo("No medicines", "Add a medicine first.")
            return
        m = meds[0]
        self.show_reminder(m, m.times[0], test=True)

    # ------------------------------------------------------------ medicines tab
    def _build_meds_tab(self):
        bar = ttk.Frame(self.tab_meds)
        bar.pack(fill="x", pady=(0, 10))
        self.q = tk.StringVar()
        self.cat_f = tk.StringVar(value="All")
        self.stat_f = tk.StringVar(value="All")
        ttk.Label(bar, text="\U0001f50d Search").pack(side="left")
        e = ttk.Entry(bar, textvariable=self.q, width=28)
        e.pack(side="left", padx=(6, 14))
        ttk.Label(bar, text="Category").pack(side="left")
        ttk.Combobox(bar, textvariable=self.cat_f, values=["All"] + CATEGORIES, state="readonly",
                     width=22).pack(side="left", padx=(6, 14))
        ttk.Label(bar, text="Status").pack(side="left")
        ttk.Combobox(bar, textvariable=self.stat_f, state="readonly", width=12,
                     values=["All", "Active", "Inactive", "Expired", "Scheduled", "Low stock"]).pack(side="left", padx=6)
        ttk.Button(bar, text="Clear", command=self.clear_filters).pack(side="left", padx=6)
        for v in (self.q, self.cat_f, self.stat_f):
            v.trace_add("write", lambda *a: self.refresh_meds())

        cols = ("name", "dosage", "category", "times", "stock", "course", "status")
        wrap = tk.Frame(self.tab_meds, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        wrap.pack(fill="both", expand=True)
        self.med_tree = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse")
        for c, w, t in (("name", 210, "Medicine"), ("dosage", 100, "Dosage"), ("category", 150, "Category"),
                        ("times", 170, "Dose times"), ("stock", 70, "Stock"),
                        ("course", 190, "Course"), ("status", 90, "Status")):
            self.med_tree.heading(c, text=t)
            self.med_tree.column(c, width=w, anchor="w")
        for tag, col in (("Expired", RED), ("Inactive", MUTED), ("Low", AMBER), ("Scheduled", BLUE)):
            self.med_tree.tag_configure(tag, foreground=col)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.med_tree.yview)
        self.med_tree.configure(yscrollcommand=sb.set)
        self.med_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.med_tree.bind("<Double-1>", lambda e: self.edit_med())

        row = ttk.Frame(self.tab_meds)
        row.pack(fill="x", pady=(10, 0))
        ttk.Button(row, text="\uff0b Add medicine", style="Accent.TButton",
                   command=lambda: MedicineDialog(self)).pack(side="left")
        ttk.Button(row, text="Edit", command=self.edit_med).pack(side="left", padx=8)
        ttk.Button(row, text="Refill stock", command=self.refill).pack(side="left")
        ttk.Button(row, text="Pause / Resume", command=self.toggle_active).pack(side="left", padx=8)
        ttk.Button(row, text="Delete", style="Danger.TButton", command=self.delete_med).pack(side="left")
        self.count_lbl = ttk.Label(row, text="")
        self.count_lbl.pack(side="right")

    def clear_filters(self):
        self.q.set("")
        self.cat_f.set("All")
        self.stat_f.set("All")

    def refresh_meds(self):
        today = datetime.now().date()
        found = logic.search(self.store.medicines, self.q.get(), self.cat_f.get(), self.stat_f.get(), today)
        self.med_tree.delete(*self.med_tree.get_children())
        for m in found:
            st = logic.med_status(m, today)
            course = f"{m.start_date} \u2192 {m.end_date or 'ongoing'}"
            tag = st if st in ("Expired", "Inactive", "Scheduled") else ("Low" if m.stock <= logic.LOW_STOCK_THRESHOLD else "")
            self.med_tree.insert("", "end", iid=m.id, tags=(tag,),
                                 values=(m.name, m.dosage, m.category, ", ".join(m.times), m.stock, course, st))
        self.count_lbl.config(text=f"Showing {len(found)} of {len(self.store.medicines)} medicines")

    def _selected_med(self):
        sel = self.med_tree.selection()
        if not sel:
            messagebox.showinfo("Select a medicine", "Please select a medicine in the list first.")
            return None
        return self.store.get(sel[0])

    def edit_med(self):
        m = self._selected_med()
        if m:
            MedicineDialog(self, m)

    def refill(self):
        m = self._selected_med()
        if not m:
            return
        n = simpledialog.askinteger("Refill stock", f"Units to add to {m.name}:", parent=self.root,
                                    minvalue=1, maxvalue=MAX_STOCK)
        if n:
            m.stock = min(MAX_STOCK, m.stock + n)
            self.store.save()
            self.refresh_all()
            self.set_status(f"{m.name} stock is now {m.stock}.")

    def toggle_active(self):
        m = self._selected_med()
        if m:
            m.active = not m.active
            self.store.save()
            self.refresh_all()
            self.set_status(f"{m.name} {'resumed' if m.active else 'paused'}.")

    def delete_med(self):
        m = self._selected_med()
        if m and messagebox.askyesno("Delete medicine", f"Delete {m.name} {m.dosage} and its dose history?"):
            self.store.delete(m.id)
            self.store.save()
            self.refresh_all()
            self.set_status(f"Deleted {m.name}.")

    # ------------------------------------------------------------ analytics
    def _build_stats_tab(self):
        self.tab_stats.columnconfigure(1, weight=1)
        self.tab_stats.rowconfigure(0, weight=1)
        left = tk.Frame(self.tab_stats, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        tk.Label(left, text="Executive summary", bg=CARD, font=("Segoe UI", 13, "bold"),
                 anchor="w").pack(fill="x", padx=14, pady=(12, 4))
        self.summary_box = tk.Text(left, width=52, wrap="none", bg=CARD, relief="flat",
                                   font=("Consolas", 9), padx=12, state="disabled")
        self.summary_box.pack(fill="both", expand=True)
        right = ttk.Frame(self.tab_stats)
        right.grid(row=0, column=1, sticky="nsew")
        self.chart_nb = ttk.Notebook(right)
        self.chart_nb.pack(fill="both", expand=True)
        ttk.Button(right, text="\u21bb Refresh charts", command=lambda: self.refresh_analytics(force=True)).pack(
            anchor="e", pady=(8, 0))
        self._chart_signature = None

    def refresh_analytics(self, force: bool = False):
        if self.nb.select() != str(self.tab_stats) and not force:
            return
        now = datetime.now()
        text = reports.summary_text(self.store.medicines, self.store.logs, now)
        self.summary_box.config(state="normal")
        self.summary_box.delete("1.0", "end")
        self.summary_box.insert("end", text)
        self.summary_box.config(state="disabled")

        sig = (len(self.store.medicines), len(self.store.logs),
               sum(m.stock for m in self.store.medicines), now.strftime("%Y%m%d%H"))
        if sig == self._chart_signature and not force:
            return
        self._chart_signature = sig
        for tab in self.chart_nb.tabs():
            self.chart_nb.forget(tab)
        try:
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            figs = reports.build_figures(self.store.medicines, self.store.logs, now)
        except ImportError:
            f = ttk.Frame(self.chart_nb, padding=30)
            ttk.Label(f, text="Matplotlib is not installed.\nRun:  pip install matplotlib",
                      font=("Segoe UI", 12)).pack()
            self.chart_nb.add(f, text="Charts")
            return
        for title, fig in figs.items():
            f = ttk.Frame(self.chart_nb)
            FigureCanvasTkAgg(fig, master=f).get_tk_widget().pack(fill="both", expand=True)
            self.chart_nb.add(f, text=f"  {title}  ")

    # ------------------------------------------------------------ reports tab
    def _build_reports_tab(self):
        box = tk.Frame(self.tab_reports, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        box.pack(fill="x")
        tk.Label(box, text="Export", bg=CARD, font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(box, text="Save your data and summary in standard formats for review or sharing.",
                 bg=CARD, fg=MUTED).pack(anchor="w", padx=16)
        r = tk.Frame(box, bg=CARD)
        r.pack(fill="x", padx=16, pady=14)
        for text, cmd in (("Markdown report", self.export_md), ("Text audit log", self.export_txt),
                          ("CSV data", self.export_csv_file), ("Chart images (PNG)", self.export_charts)):
            ttk.Button(r, text=text, command=cmd).pack(side="left", padx=(0, 8))

        box2 = tk.Frame(self.tab_reports, bg=CARD, highlightbackground="#e2e8f0", highlightthickness=1)
        box2.pack(fill="both", expand=True, pady=(14, 0))
        tk.Label(box2, text="Bulk import (CSV)", bg=CARD, font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(box2, text="Columns: name, dosage, category, times, start_date, end_date, stock, notes. "
                            "Invalid rows are skipped and listed below.", bg=CARD, fg=MUTED).pack(anchor="w", padx=16)
        ttk.Button(box2, text="Import CSV file\u2026", style="Accent.TButton", command=self.import_csv_file).pack(
            anchor="w", padx=16, pady=10)
        self.import_log = tk.Text(box2, height=12, wrap="word", font=("Consolas", 9), bg="#f8fafc", relief="flat",
                                  padx=10, pady=8, state="disabled")
        self.import_log.pack(fill="both", expand=True, padx=16, pady=(0, 16))

    def _ask_path(self, title, ext, name):
        EXPORT_DIR.mkdir(exist_ok=True)
        return filedialog.asksaveasfilename(title=title, defaultextension=ext, initialdir=EXPORT_DIR,
                                            initialfile=name, filetypes=[(ext.upper().strip("."), f"*{ext}")])

    def _export(self, title, ext, name, fn):
        path = self._ask_path(title, ext, name)
        if not path:
            return
        try:
            fn(path)
            self.set_status(f"Exported {path}")
            messagebox.showinfo("Export complete", f"Saved to:\n{path}")
        except OSError as e:
            messagebox.showerror("Export failed", str(e))

    def export_md(self):
        self._export("Save Markdown report", ".md", f"report_{datetime.now():%Y%m%d}.md",
                     lambda p: reports.export_markdown(p, self.store.medicines, self.store.logs, datetime.now()))

    def export_txt(self):
        self._export("Save text audit log", ".txt", f"audit_{datetime.now():%Y%m%d}.txt",
                     lambda p: reports.export_text(p, self.store.medicines, self.store.logs, datetime.now()))

    def export_csv_file(self):
        self._export("Save CSV", ".csv", f"medicines_{datetime.now():%Y%m%d}.csv",
                     lambda p: reports.export_csv(p, self.store.medicines))

    def export_charts(self):
        folder = filedialog.askdirectory(title="Choose folder for chart images", initialdir=EXPORT_DIR)
        if not folder:
            return
        try:
            paths = reports.save_charts(folder, self.store.medicines, self.store.logs, datetime.now())
            messagebox.showinfo("Charts saved", "\n".join(p.name for p in paths) + f"\n\nSaved in:\n{folder}")
            self.set_status(f"Saved {len(paths)} charts to {folder}")
        except ImportError:
            messagebox.showerror("Matplotlib missing", "Install it with:  pip install matplotlib")

    def import_csv_file(self):
        path = filedialog.askopenfilename(title="Choose CSV file", filetypes=[("CSV", "*.csv")],
                                          initialdir=EXPORT_DIR.parent / "data")
        if not path:
            return
        try:
            added, errors = reports.import_csv(path, self.store.medicines)
        except (OSError, ValueError, UnicodeDecodeError) as e:
            messagebox.showerror("Import failed", str(e))
            return
        self.store.medicines.extend(added)
        self.store.save()
        EXPORT_DIR.mkdir(exist_ok=True)
        log_path = EXPORT_DIR / f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log"
        reports.write_import_log(log_path, path, len(added), errors)
        lines = [f"Imported {len(added)} medicine(s); rejected {len(errors)} row(s).", ""]
        lines += [f"Row {n}: {m}" for n, m in errors]
        lines += ["", f"Error log saved: {log_path}"]
        self.import_log.config(state="normal")
        self.import_log.delete("1.0", "end")
        self.import_log.insert("end", "\n".join(lines))
        self.import_log.config(state="disabled")
        self.refresh_all()
        self.set_status(f"Import finished: {len(added)} added, {len(errors)} rejected.")

    # ------------------------------------------------------------ misc
    def refresh_all(self):
        self.refresh_dashboard()
        self.refresh_meds()
        self.refresh_analytics()

    def _tick(self):
        self.clock.config(text=datetime.now().strftime("%a %d %b  %H:%M:%S"))
        self.root.after(1000, self._tick)

    def on_close(self):
        self.store.save()
        self.root.destroy()


def run():
    root = tk.Tk()
    MedicineApp(root)
    root.mainloop()
