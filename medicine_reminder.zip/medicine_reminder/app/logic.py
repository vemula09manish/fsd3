"""Core business logic: schedules, reminders, warnings, search and summary metrics."""
from __future__ import annotations

from collections import Counter
from datetime import date, datetime, timedelta

from .models import Medicine

LOW_STOCK_THRESHOLD = 5
GRACE_MINUTES = 30          # after this a dose is considered "Missed"
ENDING_SOON_DAYS = 3


def to_date(s: str):
    return datetime.strptime(s, "%Y-%m-%d").date() if s else None


def med_status(m: Medicine, today: date) -> str:
    if not m.active:
        return "Inactive"
    end = to_date(m.end_date)
    if end and end < today:
        return "Expired"
    if to_date(m.start_date) and to_date(m.start_date) > today:
        return "Scheduled"
    return "Active"


def scheduled_on(m: Medicine, day: date) -> bool:
    if not m.active:
        return False
    start, end = to_date(m.start_date), to_date(m.end_date)
    return (not start or start <= day) and (not end or day <= end)


def log_index(logs: list) -> dict:
    """(med_id, date, time) -> status; later entries win."""
    return {(l["med_id"], l["date"], l["time"]): l["status"] for l in logs}


def today_schedule(meds, logs, now: datetime) -> list[dict]:
    idx, day, rows = log_index(logs), now.date(), []
    for m in meds:
        if not scheduled_on(m, day):
            continue
        for t in m.times:
            key = (m.id, day.isoformat(), t)
            if key in idx:
                status = idx[key]
            else:
                sched = datetime.combine(day, datetime.strptime(t, "%H:%M").time())
                if now < sched:
                    status = "Upcoming"
                elif now - sched <= timedelta(minutes=GRACE_MINUTES):
                    status = "Due"
                else:
                    status = "Missed"
            rows.append({"med": m, "time": t, "status": status})
    rows.sort(key=lambda r: (r["time"], r["med"].name.lower()))
    return rows


def mark_dose(meds, logs, med_id, day: str, time_str: str, status: str, now: datetime) -> bool:
    """Record Taken/Skipped. Taking a dose uses one unit of stock. Returns False if already logged."""
    if (med_id, day, time_str) in log_index(logs):
        return False
    logs.append({"med_id": med_id, "date": day, "time": time_str, "status": status,
                 "logged_at": now.strftime("%Y-%m-%d %H:%M")})
    if status == "Taken":
        for m in meds:
            if m.id == med_id:
                m.stock = max(0, m.stock - 1)
    return True


def adherence_for_day(meds, logs, day: date, now: datetime):
    """Return (taken, expected) for one day. Future doses today are not counted."""
    idx, taken, expected = log_index(logs), 0, 0
    for m in meds:
        if not scheduled_on(m, day):
            continue
        for t in m.times:
            if day == now.date() and datetime.combine(day, datetime.strptime(t, "%H:%M").time()) > now:
                continue
            expected += 1
            if idx.get((m.id, day.isoformat(), t)) == "Taken":
                taken += 1
    return taken, expected


def adherence_trend(meds, logs, now: datetime, days: int = 7):
    """List of (date, pct or None) oldest -> newest."""
    out = []
    for back in range(days - 1, -1, -1):
        d = (now - timedelta(days=back)).date()
        taken, exp = adherence_for_day(meds, logs, d, now)
        out.append((d, round(100 * taken / exp, 1) if exp else None))
    return out


def get_warnings(meds, logs, now: datetime) -> list[tuple[str, str]]:
    """Threshold warning indicators -> [(level, message)] level: critical|warning|info."""
    today, out = now.date(), []
    for m in meds:
        label = f"{m.name} {m.dosage}"
        status = med_status(m, today)
        if status == "Inactive":
            continue
        if status == "Expired":
            out.append(("warning", f"{label}: course ended on {m.end_date} - review or archive it."))
            continue
        if m.stock == 0:
            out.append(("critical", f"{label}: OUT OF STOCK - refill now."))
        elif m.stock <= LOW_STOCK_THRESHOLD:
            out.append(("warning", f"{label}: low stock ({m.stock} left)."))
        end = to_date(m.end_date)
        if end and 0 <= (end - today).days <= ENDING_SOON_DAYS:
            out.append(("info", f"{label}: course ends in {(end - today).days} day(s) ({m.end_date})."))
    for r in today_schedule(meds, logs, now):
        if r["status"] == "Missed":
            out.append(("critical", f"Missed dose: {r['med'].name} {r['med'].dosage} at {r['time']}."))
        elif r["status"] == "Due":
            out.append(("warning", f"Due now: {r['med'].name} {r['med'].dosage} ({r['time']})."))
    order = {"critical": 0, "warning": 1, "info": 2}
    out.sort(key=lambda w: order[w[0]])
    return out


def search(meds, keyword: str = "", category: str = "All", status: str = "All",
           today: date | None = None) -> list[Medicine]:
    today = today or date.today()
    kw = keyword.strip().lower()
    result = []
    for m in meds:
        if kw and kw not in f"{m.name} {m.dosage} {m.category} {m.notes}".lower():
            continue
        if category != "All" and m.category != category:
            continue
        s = med_status(m, today)
        if status == "Low stock":
            if not (s in ("Active", "Scheduled") and m.stock <= LOW_STOCK_THRESHOLD):
                continue
        elif status != "All" and s != status:
            continue
        result.append(m)
    return sorted(result, key=lambda m: m.name.lower())


def summary(meds, logs, now: datetime) -> dict:
    today = now.date()
    statuses = Counter(med_status(m, today) for m in meds)
    live = [m for m in meds if med_status(m, today) in ("Active", "Scheduled")]
    doses_per_day = sum(len(m.times) for m in live)
    taken = expected = 0
    for back in range(7):
        t, e = adherence_for_day(meds, logs, (now - timedelta(days=back)).date(), now)
        taken, expected = taken + t, expected + e
    sched = today_schedule(meds, logs, now)
    return {
        "total": len(meds),
        "active": statuses["Active"], "inactive": statuses["Inactive"],
        "expired": statuses["Expired"], "scheduled": statuses["Scheduled"],
        "by_category": Counter(m.category for m in meds),
        "doses_per_day": doses_per_day,
        "avg_doses_per_med": round(doses_per_day / len(live), 2) if live else 0,
        "avg_stock": round(sum(m.stock for m in live) / len(live), 1) if live else 0,
        "low_stock": [m for m in live if m.stock <= LOW_STOCK_THRESHOLD],
        "adherence_7d": round(100 * taken / expected, 1) if expected else None,
        "today_total": len(sched),
        "today_taken": sum(1 for r in sched if r["status"] == "Taken"),
        "today_missed": sum(1 for r in sched if r["status"] == "Missed"),
        "today_pending": sum(1 for r in sched if r["status"] in ("Upcoming", "Due")),
        "trend": adherence_trend(meds, logs, now, 7),
    }
