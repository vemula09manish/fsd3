"""JSON persistence with corruption recovery and first-run demo seeding."""
from __future__ import annotations

import json
import random
import shutil
from datetime import datetime, timedelta
from pathlib import Path

from .models import Medicine

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
EXPORT_DIR = BASE_DIR / "exports"
DB_FILE = DATA_DIR / "medicines.json"
SAMPLE_FILE = DATA_DIR / "sample_medicines.json"


class Store:
    def __init__(self, path: Path | None = None, seed_demo: bool = True):
        self.path = Path(path) if path else DB_FILE
        self.seed_demo = seed_demo
        self.medicines: list[Medicine] = []
        self.logs: list[dict] = []
        self.notice = ""   # message about recovery / seeding for the UI

    # ---------- load / save ----------
    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or "medicines" not in data:
                raise ValueError("Unexpected file layout")
            self.medicines = [Medicine.from_dict(d) for d in data["medicines"]]
            self.logs = [l for l in data.get("logs", []) if isinstance(l, dict)]
        except FileNotFoundError:
            self._first_run()
        except (json.JSONDecodeError, ValueError, TypeError, KeyError):
            backup = self.path.with_suffix(".corrupt.bak")
            try:
                shutil.copy(self.path, backup)
            except OSError:
                pass
            self.medicines, self.logs = [], []
            self.notice = f"Data file was unreadable. A backup was saved as {backup.name} and a clean file was created."
            self.save()

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"medicines": [m.to_dict() for m in self.medicines], "logs": self.logs},
                      f, indent=2, ensure_ascii=False)
        tmp.replace(self.path)

    # ---------- first run ----------
    def _first_run(self):
        self.medicines, self.logs = [], []
        if self.seed_demo and SAMPLE_FILE.exists():
            try:
                with open(SAMPLE_FILE, "r", encoding="utf-8") as f:
                    self.medicines = [Medicine.from_dict(d) for d in json.load(f)["medicines"]]
                self.logs = self._demo_logs()
                self.notice = "Welcome! Demo data was loaded so you can explore the app."
            except (OSError, ValueError, KeyError):
                self.medicines = []
        self.save()

    def _demo_logs(self) -> list[dict]:
        """Generate realistic dose history for the past 7 days."""
        rng = random.Random(42)
        now = datetime.now()
        logs = []
        for back in range(7, 0, -1):
            day = (now - timedelta(days=back)).date()
            for m in self.medicines:
                if not m.active or m.start_date > day.isoformat():
                    continue
                if m.end_date and m.end_date < day.isoformat():
                    continue
                for t in m.times:
                    r = rng.random()
                    if r < 0.82:
                        status = "Taken"
                    elif r < 0.90:
                        status = "Skipped"
                    else:
                        continue  # missed (no log)
                    logs.append({"med_id": m.id, "date": day.isoformat(), "time": t,
                                 "status": status, "logged_at": f"{day.isoformat()} {t}"})
        return logs

    # ---------- helpers ----------
    def get(self, med_id: str):
        return next((m for m in self.medicines if m.id == med_id), None)

    def delete(self, med_id: str):
        self.medicines = [m for m in self.medicines if m.id != med_id]
        self.logs = [l for l in self.logs if l.get("med_id") != med_id]
