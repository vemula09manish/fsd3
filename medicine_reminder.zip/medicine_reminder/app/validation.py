"""Defensive input validation shared by the GUI form and the CSV importer."""
from __future__ import annotations

import re
from datetime import datetime

from .models import CATEGORIES

NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .,'()+/\-]{1,59}$")
TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
MAX_STOCK = 10000
MAX_TIMES_PER_DAY = 8


def parse_times(raw: str):
    """Parse '8:00, 20:00' / '08:00;20:00' / '08:00 20:00' -> (['08:00','20:00'], errors)."""
    errors, times = [], []
    parts = [p for p in re.split(r"[,;|\s]+", (raw or "").strip()) if p]
    if not parts:
        return [], ["At least one dose time (HH:MM) is required."]
    for p in parts:
        m = TIME_RE.match(p)
        if not m:
            errors.append(f"Invalid time '{p}' - use 24-hour HH:MM (e.g. 08:30).")
        else:
            times.append(f"{int(m.group(1)):02d}:{m.group(2)}")
    times = sorted(set(times))
    if len(times) > MAX_TIMES_PER_DAY:
        errors.append(f"At most {MAX_TIMES_PER_DAY} doses per day are allowed.")
    return times, errors


def parse_date(raw: str, label: str, required: bool):
    raw = (raw or "").strip()
    if not raw:
        return ("", [f"{label} is required."]) if required else ("", [])
    try:
        return datetime.strptime(raw, "%Y-%m-%d").date().isoformat(), []
    except ValueError:
        return "", [f"{label} '{raw}' is not a valid date - use YYYY-MM-DD."]


def validate_medicine_form(values: dict, existing=None, ignore_id=None):
    """Validate raw form/CSV values.

    Returns (clean_dict, errors). clean_dict is None when errors exist.
    `existing` is a list of Medicine used for duplicate detection.
    """
    errors = []

    name = re.sub(r"\s+", " ", str(values.get("name", "")).strip())
    if not name:
        errors.append("Medicine name is required.")
    elif not NAME_RE.match(name):
        errors.append("Name must be 2-60 characters (letters, digits, space and . , ' ( ) + / -).")

    dosage = str(values.get("dosage", "")).strip()
    if not dosage:
        errors.append("Dosage is required (e.g. '500 mg', '1 tablet').")
    elif len(dosage) > 30:
        errors.append("Dosage must be 30 characters or fewer.")

    cat_raw = str(values.get("category", "")).strip()
    category = next((c for c in CATEGORIES if c.lower() == cat_raw.lower()), None)
    if category is None:
        errors.append(f"Category '{cat_raw}' is not valid. Choose one of: {', '.join(CATEGORIES)}.")

    times, t_err = parse_times(str(values.get("times", "")))
    errors += t_err

    start, e1 = parse_date(values.get("start_date", ""), "Start date", True)
    end, e2 = parse_date(values.get("end_date", ""), "End date", False)
    errors += e1 + e2
    if start and end and end < start:
        errors.append("End date cannot be before the start date.")

    stock_raw = str(values.get("stock", "")).strip()
    stock = 0
    if stock_raw == "":
        errors.append("Stock is required (use 0 if none left).")
    else:
        try:
            stock = int(float(stock_raw))
            if float(stock_raw) != stock:
                raise ValueError
            if not 0 <= stock <= MAX_STOCK:
                errors.append(f"Stock must be between 0 and {MAX_STOCK}.")
        except ValueError:
            errors.append(f"Stock '{stock_raw}' must be a whole number.")

    notes = str(values.get("notes", "")).strip()
    if len(notes) > 200:
        errors.append("Notes must be 200 characters or fewer.")

    active_raw = values.get("active", True)
    if isinstance(active_raw, str):
        active = active_raw.strip().lower() not in ("false", "0", "no", "n", "inactive")
    else:
        active = bool(active_raw)

    if name and dosage and existing:
        for m in existing:
            if m.id != ignore_id and m.name.lower() == name.lower() and m.dosage.lower() == dosage.lower():
                errors.append(f"'{name} {dosage}' already exists.")
                break

    if errors:
        return None, errors
    return {
        "name": name, "dosage": dosage, "category": category, "times": times,
        "start_date": start, "end_date": end, "stock": stock,
        "notes": notes, "active": active,
    }, []
