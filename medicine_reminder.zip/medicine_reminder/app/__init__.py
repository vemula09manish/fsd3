"""MediMinder - Medicine Schedule Reminder (Python for Good, Project #36)."""
__version__ = "1.0.0"
